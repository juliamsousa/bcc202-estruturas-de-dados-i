//
//  MatrizMain.cpp
//  
//
//
//

#include<stdio.h>
#include<iostream>
using namespace std;


int main()
{
    string name;
    cin>> name;
    
    cout<<"Hello World, " << name << "!\n";
}




