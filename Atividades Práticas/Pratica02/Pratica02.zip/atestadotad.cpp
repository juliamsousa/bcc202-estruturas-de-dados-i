#include <iostream>
#include <cstring>
#include <iomanip>
#include "alunotad.hpp"
#include "disciplinatad.hpp"
#include "atestadotad.hpp"
using namespace std;

struct atestado 
{
	Taluno* aluno;
	
	Tdisciplina** disciplinas;
	
	int horasAula;
};

Tatestado* criarAtestado (int n)
{
	Tatestado* aux = new Tatestado;
	
	aux->aluno = criarAluno();
	
	aux->disciplinas = new Tdisciplina*;
	
	for (int i=0; i<n; i++)
		aux->disciplinas[i] = criarDisciplina();

	return aux;
}

void desalocarAtestado (Tatestado* atestado, int n)
{
	desalocarAluno(atestado->aluno);
	
	for (int i=0; i<n; i++)
		desalocarDisciplina(atestado->disciplinas[i]);
		
	delete [] atestado->disciplinas;
		
	delete atestado;
}

void preencheAtestado (Tatestado* atestado, int n)
{
	int ch=0;
	long double cpf;
	long int matricula;
	int carga, sala, dd, mm, yy;
	char nome [30];
	char codigo [15];
	char curso [30];
	
	cout<<"Digite o nome do aluno: "<<endl;
	cin>>nome;
	cout<<"Digite o CPF do aluno: "<<endl;
	cin>>cpf;
	cout<<"Digite a matricula do aluno: "<<endl;
	cin>>matricula;
	cout<<"Digite o curso do aluno: "<<endl;
	cin>>curso;
	cout<<"Digite a data de ingresso (dia/mes/ano): "<<endl;
	cin>>dd>>mm>>yy;
	
	preencheAluno(atestado->aluno, cpf, nome, matricula, curso, dd, mm, yy);
	
	for (int i=0; i<n; i++)
	{
		if (ch<=28)
		{
			cout<<"Digite o nome da disciplina."<<endl;
			cin>>nome;
			cout<<"Digite o codigo da disciplina."<<endl;
			cin>>codigo;
			cout<<"Digite o curso da disciplina."<<endl;
			cin>>curso;
			cout<<"Digite a carga horaria da disciplina."<<endl;
			cin>>carga;
			cout<<"Digite a sala da disciplina."<<endl;
			cin>>sala;
				 
			preencheDisciplina(atestado->disciplinas[i], nome, codigo, carga, curso, sala);		
			
			ch+=acessarCH(atestado->disciplinas[i]);
		}
		else 
			cout<<"Horas permitidas atingidas."<<endl;
	}
	
	atestado->horasAula = ch;
}

void alterarAluno (Tatestado* atestado)
{
	int t, talunos;

	do 
	{
		cout<<"**Opcao aluno**"<<endl;
		cout<<"1 - Alterar dados"<<endl;
		cout<<"2 - Acessar dados"<<endl;
		cout<<"0 - Sair do menu aluno"<<endl<<endl;
	
		cin>>t;
	
		switch (t) 
		{
			case 1: 
			{
				int a;
	
				cout<<"**Alterar dados**"<<endl;
				cout<<"11 - Alterar o CPF "<<endl;
				cout<<"12 - Alterar o nome"<<endl;
				cout<<"13 - Alterar a matricula"<<endl;
				cout<<"14 - Alterar o curso"<<endl;
				cout<<"15 - Alterar a data de ingresso"<<endl;
	
				cin>>a;
	
				switch (a) 
				{
					case 11: 
					{
						long double cpf;

						cout<<"Digite o CPF: "<<endl;
						cin>>cpf;
	
						inserirCPFAluno(atestado->aluno, cpf);
					}
					break;
	
					case 12: 
					{
						char nome[50];

						cout<<"Digite o nome: "<<endl;
						cin>>nome;
	
						inserirNomeAluno(atestado->aluno, nome);
					}
					break;
	
					case 13: 
					{
						long int matricula;
						
						cout<<"Digite a matricula: "<<endl;
						cin>>matricula;
	
						inserirMatriculaAluno(atestado->aluno, matricula);
					}
					break;
	
					case 14: 
					{
						char curso [30];

						cout<<"Digite o curso: "<<endl;
						cin>>curso;
	
						inserirCursoAluno(atestado->aluno, curso);
					}
					break;
	
					case 15: 
					{
						int dd, mm, yy;
	
						cout<<"Digite a data de ingresso (dia/mes/ano): "<<endl;
						cin>>dd, mm, yy;
	
						inserirDataAluno(atestado->aluno, dd, mm, yy);
					}
				}
			}
			break;
	
			case 2:
			{
				int b;
	
				cout<<"**Acesso a dados**"<<endl;;
				cout<<"21 - Acessar o CPF "<<endl;
				cout<<"22 - Acessar o nome"<<endl;
				cout<<"23 - Acessar a matricula"<<endl;
				cout<<"24 - Acessar o curso"<<endl;
				cout<<"25 - Acesar a data de ingresso"<<endl;
	
				cin>>b;
	
				switch (b) 
				{
					case 21: 
					{
						int n;

						cout<<"CPF: "<<acessarCPFAluno(atestado->aluno)<<endl;
					}
					break;
	
					case 22: 
					{
						char nome [50];
					
						acessarNomeAluno (atestado->aluno, nome);
	
						cout<<"Nome: "<<nome<<endl;
					}
					break;
	
					case 23: 
					{
						cout<<"Matricula: "<<acessarMatriculaAluno(atestado->aluno)<<endl;
					}
					break;
	
					case 24: 
					{
						char curso[30];
	
						acessarCursoAluno (atestado->aluno, curso);
	
						cout<<"Curso: "<<curso<<endl;
					}
					break;
	
					case 25: 
					{
						int n, d, m, a;

						acessarDataAluno (atestado->aluno, &d, &m, &a);
	
						cout<<"Data de ingresso: "<<d<<"/"<<m<<"/"<<a<<endl;
					}
					break;
				}
			}
			break;
		}
	} while (t != 0);
}

void alterarDisciplinaAtestado (Tatestado* atestado)
{
	int t, tdisciplina;
	
	do 
	{
		cout<<"**Opcao disciplina**"<<endl;
		cout<<"1 - Alterar dados"<<endl;
		cout<<"2 - Acessar dados"<<endl;
		cout<<"0 - Sair do menu disciplina"<<endl<<endl;
	
		cin>>t;
	
		switch (t) 
		{
			case 1: 
			{
				int u;
	
				cout<<"**Alterar dados**"<<endl;
				cout<<"11 - Alterar o nome "<<endl;
				cout<<"12 - Alterar o codigo"<<endl;
				cout<<"13 - Alterar a carga horaria"<<endl;
				cout<<"14 - Alterar o curso"<<endl;
				cout<<"15 - Alterar a sala"<<endl;
	
				cin>>u;
	
				switch (u) 
				{
					case 11: 
					{
						int n;
						char nome [30];
	
						cout<<"Digite a posicao da disciplina desejada:"<<endl;
						cin>>n;
						cout<<"Digite o nome: "<<endl;
						cin>>nome;
	
						inserirNomeDisciplina(atestado->disciplinas[n-1], nome);
					}
					break;
	
					case 12: 
					{
						int n;
						char codigo [15];
	
						cout<<"Digite a posicao da disciplina desejada:"<<endl;
						cin>>n;
						cout<<"Digite o codigo: "<<endl;
						cin>>codigo;
	
						inserirCodigo(atestado->disciplinas[n-1], codigo);
					}
					break;
	
					case 13: 
					{
						int n;
						int carga;
	
						cout<<"Digite a posicao da disciplina desejada:"<<endl;
						cin>>n;
						cout<<"Digite a carga horaria: "<<endl;
						cin>>carga;
	
						inserirCH(atestado->disciplinas[n-1], carga);
					}
					break;
	
					case 14: 
					{
						int n;
						char curso [30];
	
						cout<<"Digite a posicao da disciplina desejada:"<<endl;
						cin>>n;
						cout<<"Digite o curso: "<<endl;
						cin>>curso;
	
						inserirCurso(atestado->disciplinas[n-1], curso);
					}
					break;
	
					case 15: 
					{
						int n;
						int numero;
	
						cout<<"Digite a posicao da disciplina desejada:"<<endl;
						cin>>n;
						cout<<"Digite o numero da sala: "<<endl;
						cin>>numero;
	
						inserirSala(atestado->disciplinas[n-1], numero);
					}
					break;
				}
			}
			break;
	
			case 2: 
			{
				int v;
	
				cout<<"**Acesso a dados**"<<endl;
				cout<<"21 - Acessar o nome "<<endl;
				cout<<"22 - Acessar o codigo"<<endl;
				cout<<"23 - Acessar a carga horaria"<<endl;
				cout<<"24 - Acessar o curso"<<endl;
				cout<<"25 - Acessar a sala"<<endl;
	
				cin>>v;
	
				switch (v) 
				{
					case 21: 
					{
						char nome [30];
						int n;
	
						cout<<"Digite a posicao da disciplina desejada: "<<endl;
						cin>>n;
	
						acessarNomeDisciplina (atestado->disciplinas[n-1], nome);
	
						cout<<"Nome: "<<nome<<endl;
					}
					break;
	
					case 22: 
					{
						int n;
						char code [15];
	
						cout<<"Digite a posicao da disciplina desejada: "<<endl;
						cin>>n;
	
						acessarCodigo(atestado->disciplinas[n-1], code);
	
						cout<<"Codigo: "<<code<<endl;
					}
					break;
	
					case 23: 
					{
						int n;
	
						cout<<"Digite a posicao da disciplina desejada: "<<endl;
						cin>>n;
	
						cout<<"Carga horaria: "<<acessarCH(atestado->disciplinas[n-1])<<" h"<<endl;
					}
					break;
	
					case 24: 
					{
						char curso [30];
						int n;
	
						cout<<"Digite a posicao da disciplina desejada: "<<endl;
						cin>>n;
	
						acessarCurso (atestado->disciplinas[n-1], curso);
	
						cout<<"Curso: "<<curso<<endl;
					}
					break;
	
					case 25: 
					{
						int n;
	
						cout<<"Digite a posicao da disciplina desejada: "<<endl;
						cin>>n;
	
						cout<<"Sala: "<<acessarSala(atestado->disciplinas[n-1])<<endl;
					}
					break;
				}
			}
			break;
		}
	} while (t != 0);
}

void imprimirAtestado (Tatestado* atestado, int n)
{
	imprimirAluno(atestado->aluno);
	cout<<endl;
	
	for (int i=0; i<n; i++)
	{
		imprimirDisciplina(atestado->disciplinas[i]);
		cout<<endl<<endl;
	}
	
	cout<<"Carga horaria "<<atestado->horasAula<<" h"<<endl<<endl;
}
