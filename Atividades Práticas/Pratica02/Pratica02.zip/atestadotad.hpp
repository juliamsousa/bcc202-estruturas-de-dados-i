#include <iostream>
#include <cstring>
#include "alunotad.hpp"
#include "disciplinatad.hpp"
using namespace std;

typedef struct atestado Tatestado;

Tatestado* criarAtestado (int n);

void desalocarAtestado (Tatestado* atestado, int n);

void preencheAtestado (Tatestado* atestado, int n);

void alterarAluno (Tatestado* atestado);

void alterarDisciplinaAtestado (Tatestado* atestado);

void imprimirAtestado (Tatestado* atestado, int n);
