#include <iostream>
#include "professortad.hpp"
#include "disciplinatad.hpp"
using namespace std;

typedef struct encargo Tencargo;

Tencargo* criarEncargo (int n);

void desalocarEncargo (Tencargo* encargo, int n);

void preencheEncargo (Tencargo* encargo, int n);

void alterarProfessor (Tencargo* encargo);

void alterarDisciplinaEncargo (Tencargo* encargo);

void imprimirEncargo (Tencargo* encargo, int n);
