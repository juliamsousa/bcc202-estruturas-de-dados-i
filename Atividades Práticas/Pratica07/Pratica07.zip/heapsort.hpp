#include <iostream>
#include <ctime>
using namespace std;

void heapSort (int *v, int n, int* comp, int* trocas, double* tempo); 
