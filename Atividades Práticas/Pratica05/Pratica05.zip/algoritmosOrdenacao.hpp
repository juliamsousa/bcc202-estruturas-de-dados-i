#include <iostream>
using namespace std;

void bubbleSort (int* vetor, int tamanho);

void selectionSort (int* vetor, int tamanho);

void insertionSort (int* vetor, int tamanho);

void mergeSortRecursivo (int* vetor, int tamanho);

void mergeSortIterativo (int* vetor, int tamanho);
