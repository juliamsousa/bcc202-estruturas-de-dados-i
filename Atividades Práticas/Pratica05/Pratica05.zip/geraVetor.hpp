#include <iostream>
using namespace std;

int* geraVetorAleatorio (int tamanho);

int* geraVetorCrescente (int tamanho);

int* geraVetorDecrescente (int tamanho);

void imprimeVetor (int tamanho, int* vetor);

void desalocaVetor (int* vetor);


