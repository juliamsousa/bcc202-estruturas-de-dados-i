#include <iostream>
#include <cmath>
using namespace std;

//funcao para calcular exponencial de forma recursiva
float exponenciacaoRecursiva (int base, int expoente);
